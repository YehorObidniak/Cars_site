import sqlite3 as sql
from websites import Car


class DbManager:
    def __init__(self):
        self.base = sql.connect("db.sqlite3")
        self.cur = self.base.cursor()
        if self.base:
            print("Database connected succesfully")

    def reset_active_field(self, domain):
        self.cur.execute(
            "UPDATE main_car_any WHERE site = (?)  SET active =(?)",
            (
                domain,
                False,
            ),
        )
        self.base.commit()

    def get_db_listings(self, site):
        return self.cur.execute(
            "SELECT url, price FROM main_car_any WHERE site=(?)", (site,)
        ).fetchall()

    def remove_listings(self, url):
        self.cur.execute("DELETE FROM main_car_any WHERE active=(?)", (False,))
        self.base.commit()

    # TODO
    def get_sellers_ids(self):
        return self.cur.execute("SELECT id FROM main_car_any").fetchall()

    def upsert_listing(self, car: Car):
        self.cur.execute(
            "INSERT INTO main_car_any (url, brand, model, color, photo, current_price, kms, year, location, regSpecs, activeListings, posted, site, contact, old_price, active) values (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?9, ?10, ?11, ?12, ?13, ?14, ?15, ?16) ON CONFLICT(url) DO UPDATE set old_price = old_price +"
            "+current_price, current_price = (?6)",
            (
                # "https://www.dubicars.com/2002-mercedes-benz-cls-500-552122.html",
                # "Mercedes-Benz",
                # "CLS 500",
                # "Grey/Silver",
                # "//www.dubicars.com/images/794e44/w_650x380/private-sellers/1ed487ab-f2cc-4938-891e-b3e964a19f24.jpg",
                # 21000,
                # 130000,
                # 2002,
                # "Al Ain",
                # "GCC",
                # 1,
                # "1678394193.8799658",
                # "Dubicars",
                # "tel:+971507730011",
                # "",
                # "True",
                car["url"],
            ),
        )
        self.base.commit()

    # def test(self):
    #     # sql_query = "DELETE FROM main_car_any url NOT IN (SELECT MIN(url) FROM lipo GROUP BY messdatum)"
    #     # self.cur.execute(sql_query)
    #     # self.base.commit()
    #     sql_query = "SELECT url FROM main_car_any WHERE url IN (SELECT url FROM main_car_any GROUP BY url HAVING COUNT(*) > 1)"
    #     # sql_query = "SELECT url FROM main_car_any WHERE url ='https://uae.yallamotor.com/used-cars/mitsubishi/lancer/2016/used-mitsubishi-lancer-2016-sharjah-1391781'"
    #     return self.cur.execute(sql_query).fetchall()
    #     # sql_query = "DELETE FROM main_car_any WHERE id IN (SELECT id FROM main_car_any GROUP BY url HAVING COUNT(*) > 1)"
    #     # self.cur.execute(sql_query)
    #     # self.base.commit()
    def get(self):
        return self.cur.execute("ALTER TABLE main_car_any DROP COLUMN id").fetchone()

    # def add_column(self):
    #     sql_query = "ALTER TABLE main_car_any ADD old_price INTEGER"
    #     self.cur.execute(sql_query)
    #     sql_query = "ALTER TABLE main_car_any ADD active BOOLEAN"
    #     self.cur.execute(sql_query)
    #     sql_query = "ALTER TABLE main_car_any RENAME COLUMN price to current_price"
    #     self.cur.execute(sql_query)

    # upsert_listing()


# print(DbManager().upsert_listing())
